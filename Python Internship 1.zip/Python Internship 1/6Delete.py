import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

od=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %od)
data=curs.fetchone()

print(data)

print('Do you want to delete?')
ans=input()
if ans.lower()=='yes':
    curs.execute("delete from books where bookcd=%d" %od)
    con.commit()
    print('Book is delete successfully')
else:    
    print('Book is not deleted')

con.close()    