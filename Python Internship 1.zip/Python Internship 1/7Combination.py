import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

auc=input('Enter Book Auther Name: ')
pbm=input('Enter Book Publication: ')

curs.execute("select * from books where bookau='%s' and bookpb='%s'" %(auc,pbm))
data=curs.fetchall()

try:
    for rec in data:
       print('%s' %(rec[1]))
except:
    print('Combination is not match')      

con.close