import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

com=int(input('Enter Book Code: '))
nac=input('Enter Book Name: ')
cam=input('Enter Book Category: ')
auc=input('Enter Book Auther Name: ')
pbn=input('Enter Book Publication: ')
edk=int(input('Enter Book Edition: '))
prn=float(input('Enter Book Price: '))
rev=input('Enter Book Review: ')

try:
    curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f,'%s')" %(com,nac,cam,auc,pbn,edk,prn,rev))
    con.commit()
    print('Book is added successfully')
except Exception as e:
    print('Data insert failed',e)

con.close()