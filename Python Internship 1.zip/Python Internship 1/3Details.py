import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

com=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %com)
data=curs.fetchone()

try:
    print('%s | %s | %s | %s | %d | %.02f | %s' %(data[1],data[2],data[3],data[4],data[5],data[6],data[7]))
except:
    print('Book not found')

con.close