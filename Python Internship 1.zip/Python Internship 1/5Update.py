import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

co=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %co)
data=curs.fetchone()

try:
    print('%s | %s | %s | %s | %d | %.02f' %(data[1],data[2],data[3],data[4],data[5],data[6]))
except:
    print('Book not found')

    ans=input('Do you want to add the book: ')
    if ans.lower()=='yes':
      nac=input('Enter Book Name: ')
      cam=input('Enter Book Category: ')
      aum=input('Enter Book Auther Name: ')
      pbm=input('Enter Book Publication: ')
      edc=int(input('Enter Book Edition: '))
      prn=float(input('Enter Book Price: '))
      rev=input('Enter Book Review: ')

      curs.execute("insert into books values(%d,'%s','%s','%s','%s',%d,%.2f,'%s')" %(co,nac,cam,aum,pbm,edc,prn,rev))
      con.commit()
      print('Book is added successfully')
     
con.close()    