import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

ca=input('Enter Book Category: ')

curs.execute("select * from books where bookct='%s'" %ca)
data=curs.fetchall()

for rec in data:
    print('%s' %(rec[1]))
con.close