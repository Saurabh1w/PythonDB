import pymysql

con=pymysql.connect(host='bitmtceivlxdcrr6svmp-mysql.services.clever-cloud.com', user='u9lzqjec7jvq5p8x', password='8Hy0dIfkyDDxt8ZnbVe3', database='bitmtceivlxdcrr6svmp')
curs=con.cursor()

com=int(input('Enter Book Code: '))

curs.execute("select * from books where bookcd=%d" %com)
data=curs.fetchone()
 
print(data)

print('Review the book: ') 
rwn=input()
curs.execute("Update books set review='%s' where bookcd=%d" %(rwn,com))
con.commit()
print('Review added succesfully')

con.close()